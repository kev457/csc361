import ssl,socket,h2.connection
response = ""
def checkSSL(Host):
    try:
        # print("checkSSL now checking:\n"+Host)
        port = 443
        HttpVer = ["1.1","1.0"]
        for index in range(len(HttpVer)):
            s = socket.socket()
            Request = "GET / HTTP/" + HttpVer[index] + "\r\nHost: " + Host + "\r\n\r\n"
            ss = ssl.wrap_socket(s, ssl_version=ssl.PROTOCOL_SSLv23)
            ss.connect((Host, port))
            ss.send(Request.encode())
            global response
            response = ss.recv(1024).decode()
            # print(response)
            line = response.splitlines()
            if line[0] == "HTTP/1.1 200 OK":
                # getCookies(response)
                return True
            if line[0] == "HTTP/1.1 302 Moved Temporarily"or"HTTP/1.1 301 Moved Permanently":
                substring = response.splitlines()[3]
                # print(substring)
                newHost = substring.split(": ",1)[1]
                # print(newHost)
                checkSSL(newHost)
            else:
                return False
        ss.close()

    except:
        return False

def newcheckSSL(tokenHost):
    try:
        # print("checkSSL now checking:\n"+tokenHost[1])
        port = 443
        HttpVer = ["1.1","1.0"]
        for index in range(len(HttpVer)):
            s = socket.socket()
            Request = "GET /"+tokenHost[2]+" HTTP/" + HttpVer[index] + "\r\nHost: " + tokenHost[1] + "\r\n\r\n"
            ss = ssl.wrap_socket(s, ssl_version=ssl.PROTOCOL_SSLv23)
            ss.connect((Host, port))
            ss.send(Request.encode())
            global response
            response = ss.recv(1024).decode()
            # print(response)
            line = response.splitlines()
            if line[0] == "HTTP/1.1 200 OK":
                # getCookies(response)
                return "1.1"
            if line[0] == "HTTP/1.1 302 Moved Temporarily"or"HTTP/1.1 301 Moved Permanently":
                substring = response.splitlines()[3]
                # print(substring)
                newHost = substring.split(": ",1)[1]
                # print(newHost)
                checkSSL(newHost)
            else:
                return "1"
        ss.close()

    except:
        return False
def verCheck(Host):
    port = 80

    s = socket.socket()
    Request = "GET / HTTP/1.1" + "\r\nHost: " + Host + "\r\n\r\n"
    # print(type(Request))
    s.connect((Host,port))
    s.send(Request.encode())
    global response
    response = s.recv(1024).decode()
    # print(response)
    line = response.splitlines()
    # print(line[0])
    if line[0] == "HTTP/1.1 200 OK":
        # getCookies(response)
        return "1.1"
    if line[0].find("HTTP/1.1 302 Moved Temporarily" \
            or "HTTP/1.1 301 Moved Permanently" ):
        # substring = response.splitlines()[1]
        # print(substring)
        # newHost = substring.split(": ", 1)[1]
        # print(newHost)
        newHost = findLocation(response)
        return(NewVerCheck(newHost))
    else:
        return "1"

def findLocation(response):
    for line in response.splitlines():
        # print("line in response is : "+ line)
        if(line.find("Location: ")!= -1):
            newHost = line.split(": ",1)[1]
            # print("The new Host in line 88 is "+ newHost)
            return newHost
def NewVerCheck(Host):
    ##tokenize Host first
    tokenHost = []
    tokenHost.append(Host.split("://")[0])
    Host = Host.split("://",1)[1]
    tokenHost.append(Host.split("/",1)[0])
    tokenHost.append(Host.split("/", 1)[1])
    # print(tokenHost)
    if(tokenHost[0]=="https"):
        return newcheckSSL(tokenHost)
    #####################
    # print(Host)
    port = 80
    s = socket.socket()
    Request = "GET /"+tokenHost[2]+ " HTTP/1.1" + "\r\nHost: " + tokenHost[1] + "\r\n\r\n"
    # print(type(Request))
    s.connect((tokenHost[1], port))
    s.send(Request.encode())
    global response
    response = s.recv(1024).decode()
    # print(response)
    line = response.splitlines()
    # print(line[0])
    if line[0] == "HTTP/1.1 200 OK":
        # getCookies(response)
        return "1.1"
    if line[0].find("HTTP/1.1 302 Moved Temporarily" \
                    or "HTTP/1.1 301 Moved Permanently"):
        substring = response.splitlines()[1]
        print("line 80 substirng is "+substring)
        newHost = substring.split(": ", 1)[1]
        print(newHost)
        return (NewVerCheck(newHost))
    else:
        return "1"


def http2check(Host):
    connection = establish_tcp_connection(Host)
    context = get_http2_ssl_context()
    tls_connection = negotiate_tls(connection,context,Host)
    # print(tls_connection)
    if(tls_connection==False):
        return(verCheck(Host))
    else:
        return ("2")



def establish_tcp_connection(Host):
    return socket.create_connection((Host, 443))

def get_http2_ssl_context():
    """
    This function creates an SSLContext object that is suitably configured for
    HTTP/2. If you're working with Python TLS directly, you'll want to do the
    exact same setup as this function does.
    """
    # Get the basic context from the standard library.
    ctx = ssl.create_default_context(purpose=ssl.Purpose.SERVER_AUTH)

    # RFC 7540 Section 9.2: Implementations of HTTP/2 MUST use TLS version 1.2
    # or higher. Disable TLS 1.1 and lower.
    ctx.options |= (
        ssl.OP_NO_SSLv2 | ssl.OP_NO_SSLv3 | ssl.OP_NO_TLSv1 | ssl.OP_NO_TLSv1_1
    )

    # RFC 7540 Section 9.2.1: A deployment of HTTP/2 over TLS 1.2 MUST disable
    # compression.
    ctx.options |= ssl.OP_NO_COMPRESSION

    # RFC 7540 Section 9.2.2: "deployments of HTTP/2 that use TLS 1.2 MUST
    # support TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256". In practice, the
    # blacklist defined in this section allows only the AES GCM and ChaCha20
    # cipher suites with ephemeral key negotiation.
    ctx.set_ciphers("ECDHE+AESGCM:ECDHE+CHACHA20:DHE+AESGCM:DHE+CHACHA20")

    # We want to negotiate using NPN and ALPN. ALPN is mandatory, but NPN may
    # be absent, so allow that. This setup allows for negotiation of HTTP/1.1.
    ctx.set_alpn_protocols(["h2", "http/1.1"])

    try:
        ctx.set_npn_protocols(["h2", "http/1.1"])
    except NotImplementedError:
        pass

    return ctx

def negotiate_tls(tcp_conn, context,Host):
    flag=True
    """
    Given an established TCP connection and a HTTP/2-appropriate TLS context,
    this function:

    1. wraps TLS around the TCP connection.
    2. confirms that HTTP/2 was negotiated and, if it was not, throws an error.
    """
    # Note that SNI is mandatory for HTTP/2, so you *must* pass the
    # server_hostname argument.
    try:
        tls_conn = context.wrap_socket(tcp_conn, server_hostname=Host)

    # Always prefer the result from ALPN to that from NPN.
    # You can only check what protocol was negotiated once the handshake is
    # complete.
        negotiated_protocol = tls_conn.selected_alpn_protocol()
        if negotiated_protocol is None:
            negotiated_protocol = tls_conn.selected_npn_protocol()

        if negotiated_protocol != "h2":
            flag = False
            return flag


    except:
        return False

    return flag


def getCookies():
    cookies = findCookies(response)
    for cookie in cookies:
        print(cookie +"\n")

def findCookies(response):
    cookies = []
    for line in response.splitlines():
        if(line.find("Set-Cookie: ")!= -1 ):
            cookies.append(line)

    return cookies



Host = input("Please enter a website\n")
if checkSSL(Host)==True:
    print("1. Support of HTTPS: yes\n")
else:
    print("1. Support of HTTPS: no\n")

print("2. The newest HTTP versions that the web server supports: HTTP/"+http2check(Host)+"\n")
print("List of Cookies: \n")
getCookies()


# Host = ["www.cbc.ca", "www.uvic.ca" ,  "www.google.ca",
#         "www.mcgill.ca",  "www.youtube.com", "www.akamai.com",
#         "www2.gov.bc.ca",  "www.python.org", "www.aircanada.com",
#         "www.bbc.com"]
# for website in Host:
#
#     print("website: " + website)
#     if checkSSL(website)==True:
#         print("1. Support of HTTPS: yes")
#     else:
#         print("1. Support of HTTPS: no")
#     print("2. The newest HTTP versions that the web server supports: HTTP/" + http2check(website) + "\n")

##getCookies(Host)



