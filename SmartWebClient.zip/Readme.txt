Author: Bowei Huang V00862433

Run the SmartWebClient.py and enter the website that you are willing to check
Please do not run any host that does not exit.
In the “www.bbc.com" example, the version is HTTP2. But it does not support https.
The cookies are list in the format of the response I get on the GET request. (Set-Cookie: …)
The website “www.akamai.com" and “www.python.org" does support http2 but does not get any cookies.
